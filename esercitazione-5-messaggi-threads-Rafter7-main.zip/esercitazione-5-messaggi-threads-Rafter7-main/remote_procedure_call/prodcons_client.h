#ifndef PRODCONS_CLIENT
#define PRODCONS_CLIENT

void init_client(int id_coda_richieste, int id_coda_risposte);

#endif