[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/f32Aawxs)
# Esercitazione di programmazione concorrente (monitor)

1. Simulazione di un disco con un vettore circolare, con monitor
2. Prelievi multipli
3. Lettori-scrittori con monitor e processi
4. Produttore-consumatore con priorità

![Points badge](../../blob/badges/.github/badges/points.svg)
