[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/1qjNZVYC)
# Esercitazione di programmazione concorrente (semafori)

1. Calcolo parallelo su un vettore condiviso (con mutua esclusione, con produttore-consumatore)
2. Coppia di buffer
3. Lettori-scrittori con semafori su una coppia di valori condivisa
4. Simulazione di un disco con un vettore circolare

![Points badge](../../blob/badges/.github/badges/points.svg)
