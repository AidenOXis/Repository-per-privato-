[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/UBgpIMxz)
# Esercitazione di programmazione concorrente (threads)

1. Una struttura dati stack thread-safe
2. Lettori-scrittori su più oggetti monitor
3. Produttore-consumatore con priorità
