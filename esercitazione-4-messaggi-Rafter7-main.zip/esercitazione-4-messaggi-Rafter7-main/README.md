[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/o1VhM9ah)
# Esercitazione di programmazione concorrente (messaggi)

1. Load Balancing
2. Server sincroni multipli
3. Grafo delle dipendenze
4. Registro distribuito

![Points badge](../../blob/badges/.github/badges/points.svg)
