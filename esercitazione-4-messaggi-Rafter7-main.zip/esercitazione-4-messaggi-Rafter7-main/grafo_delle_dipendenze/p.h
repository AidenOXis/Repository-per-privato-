#ifndef _P_H_
#define _P_H_

/* TBD: Definire delle macro da usare per il campo "type" dei messaggi */

#define P1 /*TBD*/
#define P2 /*TBD*/
#define P3 /*TBD*/
#define P4 /*TBD*/
#define P5 /*TBD*/
#define P6 /*TBD*/


/* TBD: Definire una struct per i messaggi con gli operandi (vettore di interi) */

/* TBD: Definire una struct per i messaggi con le risposte (un intero) */

#endif // _P_H_
